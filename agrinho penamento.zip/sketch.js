let truckX;

function setup() {
  createCanvas(800, 400);
  truckX = 100;
}

function draw() {
  background(135, 206, 235); // Céu azul

  drawGround();
  drawFarm();
  drawCity();
  drawCow();
  drawConnection();
  drawTruck();
  drawBalloons();
  moveTruck();
}

function drawGround() {
  fill(34, 139, 34);
  rect(0, 300, width, 100); // chão verde
}

function drawFarm() {
  fill(139, 69, 19);
  rect(50, 220, 80, 80); // casa de fazenda
  triangle(50, 220, 90, 180, 130, 220); // telhado
  fill(255);
  text("Campo", 60, 315);
}

function drawCity() {
  fill(100);
  for (let i = 0; i < 4; i++) {
    rect(600 + i * 30, 200 - i * 20, 30, 100 + i * 20);
  }
  fill(255);
  text("Cidade", 650, 315);
}

function drawCow() {
  fill(255);
  ellipse(150, 270, 40, 30); // corpo
  ellipse(140, 260, 20, 20); // cabeça
  fill(0);
  ellipse(145, 270, 5, 5); // mancha
  text("🐄", 135, 275);
}

function drawConnection() {
  stroke(255, 192, 203);
  strokeWeight(4);
  noFill();
  bezier(130, 270, 300, 100, 500, 100, 670, 270);
  noStroke();
  fill(0);
  text("Conexão: Campo ➝ Cidade", 300, 80);
}

function drawTruck() {
  fill(255);
  rect(truckX, 280, 60, 30);
  fill(0);
  ellipse(truckX + 10, 310, 15, 15);
  ellipse(truckX + 50, 310, 15, 15);
  fill(0);
  text("Leite", truckX + 10, 295);
}

function moveTruck() {
  truckX += 1;
  if (truckX > width) {
    truckX = -60; // reinicia o caminhão
  }
}

function drawBalloons() {
  fill(255, 0, 0);
  ellipse(400, 100, 20, 30);
  fill(0);
  line(400, 115, 400, 140);
  fill(0);
  text("🎈 Festa da Produção!", 320, 160);
}
